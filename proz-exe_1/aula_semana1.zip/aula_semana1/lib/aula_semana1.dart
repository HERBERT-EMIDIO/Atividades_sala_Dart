void main() {
  int numero1, numero2, soma;
  numero1 = 2;
  numero2 = 4;
  soma = numero1 + numero2;
  print("A Soma é igual a $soma.");
}
